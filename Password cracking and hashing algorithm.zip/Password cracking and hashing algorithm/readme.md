# Password Security Toolkit - Flask Edition

A comprehensive educational cybersecurity tool built with Flask, HTML, CSS, and JavaScript. This application demonstrates password security concepts including strength analysis, hash generation, and brute force simulation.

## 🚀 Features

- **Password Strength Analyzer**: Real-time analysis with entropy calculation, pattern detection, and security recommendations
- **Hash Generator**: MD5 and SHA-256 hashing with salt demonstration
- **Brute Force Simulator**: Educational demonstration of password cracking (limited to 4 characters)
- **Modern UI**: Dark theme with purple accents and smooth animations
- **Responsive Design**: Works on desktop and mobile devices
- **Server-Side Processing**: Secure backend processing with Flask

## 📁 Project Structure

```
password-toolkit/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── static/
│   ├── css/
│   │   └── style.css     # Custom styles and animations
│   └── js/
│       └── main.js       # Frontend JavaScript
└── templates/
    └── index.html        # Main HTML template
```

## 🛠️ Installation & Setup

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Step 1: Clone or Download the Project
Create a new directory and save all the files in the structure shown above.

### Step 2: Create Project Directory
```bash
mkdir password-toolkit
cd password-toolkit
```

### Step 3: Create Virtual Environment (Recommended)
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

### Step 4: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 5: Create Directory Structure
```bash
# Create directories
mkdir static
mkdir static/css
mkdir static/js
mkdir templates
```

### Step 6: Run the Application
```bash
python app.py
```

The application will be available at: `http://localhost:5000`

## 🔧 Configuration

### Development Mode
The application runs in debug mode by default. To run in production:

```python
# In app.py, change:
app.run(debug=False, host='0.0.0.0', port=5000)
```

### Environment Variables
You can set the following environment variables:

```bash
export FLASK_APP=app.py
export FLASK_ENV=development  # or production
export FLASK_DEBUG=1          # for debug mode
```

## 🎯 Usage

### Password Analyzer
1. Enter a password in the input field
2. View real-time strength analysis including:
   - Overall strength score (0-100)
   - Character composition analysis
   - Security issue detection
   - Entropy calculation
   - Personalized recommendations

### Hash Generator
1. Enter a password
2. View generated hashes:
   - Unsalted MD5 and SHA-256
   - Salted MD5 and SHA-256
   - Random salt value
3. Click on any hash to copy to clipboard

### Brute Force Simulator
1. Enter a password (maximum 4 characters for demo)
2. Click "Start Simulation"
3. View results including:
   - Success/failure status
   - Number of attempts
   - Time taken
   - Attempts per second

## 🔒 Security Features

- **Real-time Analysis**: Instant feedback on password strength
- **Pattern Detection**: Identifies common vulnerabilities
- **Educational Focus**: Demonstrates security concepts safely
- **No Data Storage**: Passwords are processed in memory only
- **Server-side Processing**: Secure backend calculations

## 🎨 UI Features

- **Dark Theme**: Modern cybersecurity-inspired design
- **Responsive Layout**: Works on all screen sizes
- **Smooth Animations**: Enhanced user experience
- **Visual Feedback**: Color-coded strength indicators
- **Interactive Elements**: Hover effects and transitions

## 📊 Technical Details

### Backend (Flask)
- **Password Analysis**: Comprehensive strength evaluation
- **Hash Generation**: Multiple algorithms with salting
- **Brute Force Simulation**: Educational attack demonstration
- **API Endpoints**: RESTful design for frontend communication

### Frontend (JavaScript)
- **Async Operations**: Non-blocking API calls
- **Debounced Input**: Optimized performance
- **Dynamic Content**: Real-time UI updates
- **Error Handling**: Graceful failure management

### Styling (CSS)
- **Tailwind CSS**: Utility-first framework
- **Custom Animations**: Enhanced visual appeal
- **Responsive Design**: Mobile-first approach
- **Dark Theme**: Professional cybersecurity aesthetic

## 🚨 Educational Disclaimer

This tool is designed for educational purposes only. The brute force simulator is intentionally limited and should not be used for actual password cracking. Always use strong, unique passwords and follow security best practices.

## 🐛 Troubleshooting

### Common Issues

**Port already in use:**
```bash
# Change port in app.py or kill existing process
lsof -ti:5000 | xargs kill -9  # macOS/Linux
netstat -ano | findstr :5000   # Windows
```

**Module not found:**
```bash
# Make sure virtual environment is activated
pip list  # Check installed packages
pip install -r requirements.txt  # Reinstall dependencies
```

**Template not found:**
```bash
# Ensure templates directory exists and contains index.html
ls -la templates/
```

**Static files not loading:**
```bash
# Ensure static directory structure is correct
ls -la static/css/
ls -la static/js/
```

## 🔄 Development

### Adding New Features
1. Backend: Add new routes in `app.py`
2. Frontend: Extend `main.js` functionality
3. Styling: Modify `style.css` for visual changes
4. Templates: Update `index.html` for layout changes

### Testing
```bash
# Run the application in debug mode
python app.py

# Test API endpoints manually
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"password":"test123"}'
```

## 📝 License

This project is for educational use. Feel free to modify and adapt for learning purposes.

## 🤝 Contributing

This is an educational project. Suggestions and improvements are welcome!

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section
2. Verify all files are in correct directories
3. Ensure Python and pip are properly installed
4. Make sure virtual environment is activated