# Enhanced app.py with advanced brute force simulator
from flask import Flask, render_template, request, jsonify
import hashlib
import string
import random
import re
import math
import time
import itertools
import threading
from collections import deque

app = Flask(__name__)

class PasswordAnalyzer:
    def __init__(self):
        self.common_passwords = [
            'password', '123456', 'password123', 'admin', 'qwerty', 
            'letmein', 'welcome', 'monkey', 'dragon', '123456789', 
            'password1', 'abc123'
        ]
        
    def analyze_password(self, password):
        """Comprehensive password analysis"""
        if not password:
            return None
            
        analysis = {
            'length': len(password),
            'has_lowercase': bool(re.search(r'[a-z]', password)),
            'has_uppercase': bool(re.search(r'[A-Z]', password)),
            'has_digits': bool(re.search(r'[0-9]', password)),
            'has_special': bool(re.search(r'[^a-zA-Z0-9]', password)),
            'has_repeated': bool(re.search(r'(.)\1{2,}', password)),
            'has_sequential': self._check_sequential(password),
            'is_common': password.lower() in self.common_passwords,
            'entropy': self._calculate_entropy(password)
        }
        
        analysis['score'] = self._calculate_strength_score(analysis)
        analysis['strength'] = self._get_strength_rating(analysis['score'])
        analysis['recommendations'] = self._generate_recommendations(analysis)
        
        return analysis
    
    def _check_sequential(self, password):
        """Check for sequential patterns"""
        sequences = ['abc', '123', 'qwe', 'asd', 'zxc']
        lower_pwd = password.lower()
        return any(seq in lower_pwd or seq[::-1] in lower_pwd for seq in sequences)
    
    def _calculate_entropy(self, password):
        """Calculate password entropy"""
        if not password:
            return 0
            
        charset_size = 0
        if re.search(r'[a-z]', password):
            charset_size += 26
        if re.search(r'[A-Z]', password):
            charset_size += 26
        if re.search(r'[0-9]', password):
            charset_size += 10
        if re.search(r'[^a-zA-Z0-9]', password):
            charset_size += 32
            
        return len(password) * math.log2(charset_size or 1)
    
    def _calculate_strength_score(self, analysis):
        """Calculate overall strength score"""
        score = 0
        
        # Length bonus
        score += min(analysis['length'] * 4, 40)
        
        # Character type bonuses
        if analysis['has_lowercase']:
            score += 5
        if analysis['has_uppercase']:
            score += 5
        if analysis['has_digits']:
            score += 5
        if analysis['has_special']:
            score += 10
            
        # Entropy bonus
        score += min(analysis['entropy'] / 4, 25)
        
        # Penalties
        if analysis['is_common']:
            score -= 30
        if analysis['has_repeated']:
            score -= 15
        if analysis['has_sequential']:
            score -= 10
            
        return max(0, min(100, score))
    
    def _get_strength_rating(self, score):
        """Get strength rating based on score"""
        if score >= 80:
            return {'rating': 'Very Strong', 'color': 'text-green-600', 'bg_color': 'bg-green-100'}
        elif score >= 60:
            return {'rating': 'Strong', 'color': 'text-blue-600', 'bg_color': 'bg-blue-100'}
        elif score >= 40:
            return {'rating': 'Medium', 'color': 'text-yellow-600', 'bg_color': 'bg-yellow-100'}
        elif score >= 20:
            return {'rating': 'Weak', 'color': 'text-orange-600', 'bg_color': 'bg-orange-100'}
        else:
            return {'rating': 'Very Weak', 'color': 'text-red-600', 'bg_color': 'bg-red-100'}
    
    def _generate_recommendations(self, analysis):
        """Generate improvement recommendations"""
        recommendations = []
        
        if analysis['length'] < 8:
            recommendations.append('Use at least 8 characters')
        if not analysis['has_lowercase']:
            recommendations.append('Add lowercase letters')
        if not analysis['has_uppercase']:
            recommendations.append('Add uppercase letters')
        if not analysis['has_digits']:
            recommendations.append('Add numbers')
        if not analysis['has_special']:
            recommendations.append('Add special characters (!@#$%^&*)')
        if analysis['has_repeated']:
            recommendations.append('Avoid repeating characters')
        if analysis['has_sequential']:
            recommendations.append('Avoid sequential patterns')
        if analysis['is_common']:
            recommendations.append('Avoid common passwords')
            
        return recommendations

class HashGenerator:
    @staticmethod
    def generate_salt(length=16):
        """Generate random salt"""
        characters = string.ascii_letters + string.digits
        return ''.join(random.choice(characters) for _ in range(length))
    
    @staticmethod
    def generate_hashes(password):
        """Generate various hashes for password"""
        if not password:
            return {}
            
        salt = HashGenerator.generate_salt()
        
        # MD5 hashes
        md5_hash = hashlib.md5(password.encode()).hexdigest()
        md5_salted = hashlib.md5((salt + password).encode()).hexdigest()
        
        # SHA-256 hashes
        sha256_hash = hashlib.sha256(password.encode()).hexdigest()
        sha256_salted = hashlib.sha256((salt + password).encode()).hexdigest()
        
        return {
            'md5': md5_hash,
            'sha256': sha256_hash,
            'md5_salted': md5_salted,
            'sha256_salted': sha256_salted,
            'salt': salt
        }

class EnhancedBruteForceSimulator:
    def __init__(self):
        # Common password patterns and dictionaries
        self.common_passwords = [
            'password', '123456', 'password123', 'admin', 'qwerty', 
            'letmein', 'welcome', 'monkey', 'dragon', '123456789', 
            'password1', 'abc123', 'iloveyou', 'princess', 'rockyou',
            'michael', 'superman', '696969', '123123', 'batman',
            'trustno1', 'hunter', '2000', 'thomas', 'Robert',
            'john', 'ferrari', 'hammer', 'summer', '12345',
            'test', 'daniel', 'master', 'jordan', 'jennifer',
            'blink182', 'michelle', 'jessica', '1234567', 'fuckyou'
        ]
        
        self.common_patterns = [
            # Years
            *[str(year) for year in range(1900, 2025)],
            # Common sequences
            'abc', '123', 'qwe', 'asd', 'zxc', 'qaz', 'wsx',
            # Keyboard patterns
            'qwerty', 'asdf', 'zxcv', '1234', 'abcd'
        ]
        
        self.character_sets = {
            'lowercase': 'abcdefghijklmnopqrstuvwxyz',
            'uppercase': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            'digits': '0123456789',
            'special': '!@#$%^&*()_+-=[]{}|;:,.<>?'
        }

    def get_charset(self, password):
        """Determine character set used in password"""
        charset = ''
        if re.search(r'[a-z]', password):
            charset += self.character_sets['lowercase']
        if re.search(r'[A-Z]', password):
            charset += self.character_sets['uppercase']
        if re.search(r'[0-9]', password):
            charset += self.character_sets['digits']
        if re.search(r'[^a-zA-Z0-9]', password):
            charset += self.character_sets['special']
        return charset or self.character_sets['lowercase']

    def dictionary_attack(self, target_hash, hash_type='md5'):
        """Perform dictionary attack"""
        attempts = 0
        
        # Try common passwords
        for pwd in self.common_passwords:
            attempts += 1
            if hash_type == 'md5':
                candidate_hash = hashlib.md5(pwd.encode()).hexdigest()
            else:
                candidate_hash = hashlib.sha256(pwd.encode()).hexdigest()
            
            if candidate_hash == target_hash:
                return {'found': True, 'password': pwd, 'attempts': attempts, 'method': 'Dictionary'}
        
        # Try common passwords with numbers
        for pwd in self.common_passwords[:10]:  # Top 10 only for performance
            for num in range(100):
                attempts += 1
                candidate = f"{pwd}{num}"
                if hash_type == 'md5':
                    candidate_hash = hashlib.md5(candidate.encode()).hexdigest()
                else:
                    candidate_hash = hashlib.sha256(candidate.encode()).hexdigest()
                
                if candidate_hash == target_hash:
                    return {'found': True, 'password': candidate, 'attempts': attempts, 'method': 'Dictionary + Numbers'}
                
                if attempts > 2000:  # Limit for performance
                    break
            if attempts > 2000:
                break
        
        return {'found': False, 'attempts': attempts, 'method': 'Dictionary'}

    def hybrid_attack(self, target_hash, password_length, hash_type='md5'):
        """Perform hybrid attack (common words + modifications)"""
        attempts = 0
        
        # Try common patterns with modifications
        for base in self.common_passwords[:5]:
            # Try with capitalization variations
            variations = [
                base.lower(),
                base.upper(),
                base.capitalize(),
                base.swapcase()
            ]
            
            for variation in variations:
                attempts += 1
                if len(variation) == password_length:
                    if hash_type == 'md5':
                        candidate_hash = hashlib.md5(variation.encode()).hexdigest()
                    else:
                        candidate_hash = hashlib.sha256(variation.encode()).hexdigest()
                    
                    if candidate_hash == target_hash:
                        return {'found': True, 'password': variation, 'attempts': attempts, 'method': 'Hybrid'}
                
                # Try with special character substitutions
                substitutions = {
                    'a': '@', 'e': '3', 'i': '1', 'o': '0', 's': '$'
                }
                
                substituted = variation
                for char, sub in substitutions.items():
                    substituted = substituted.replace(char, sub)
                    attempts += 1
                    if len(substituted) == password_length:
                        if hash_type == 'md5':
                            candidate_hash = hashlib.md5(substituted.encode()).hexdigest()
                        else:
                            candidate_hash = hashlib.sha256(substituted.encode()).hexdigest()
                        
                        if candidate_hash == target_hash:
                            return {'found': True, 'password': substituted, 'attempts': attempts, 'method': 'Hybrid L33t'}
                
                if attempts > 5000:
                    break
            if attempts > 5000:
                break
        
        return {'found': False, 'attempts': attempts, 'method': 'Hybrid'}

    def mask_attack(self, target_hash, password_length, charset, hash_type='md5'):
        """Perform mask attack with optimized brute force"""
        attempts = 0
        if password_length <= 4:
            max_attempts = len(charset) ** password_length
        else:
            max_attempts = len(charset) ** password_length  # Limit for longer passwords
        
        # Smart brute force - try most common patterns first
        if password_length <= 2:
            # For very short passwords, try all combinations
            for candidate in itertools.product(charset, repeat=password_length):
                attempts += 1
                candidate_str = ''.join(candidate)
                if hash_type == 'md5':
                    candidate_hash = hashlib.md5(candidate_str.encode()).hexdigest()
                else:
                    candidate_hash = hashlib.sha256(candidate_str.encode()).hexdigest()
                
                if candidate_hash == target_hash:
                    return {'found': True, 'password': candidate_str, 'attempts': attempts, 'method': 'Brute Force'}
                
                if attempts >= max_attempts:
                    break
        
        elif password_length == 3:
            # For 3-char passwords, prioritize certain patterns
            priority_chars = '0123456789abcdefghijklmnopqrstuvwxyz'
            
            # First try all combinations with priority characters
            for candidate in itertools.product(priority_chars, repeat=3):
                attempts += 1
                candidate_str = ''.join(candidate)
                if hash_type == 'md5':
                    candidate_hash = hashlib.md5(candidate_str.encode()).hexdigest()
                else:
                    candidate_hash = hashlib.sha256(candidate_str.encode()).hexdigest()
                
                if candidate_hash == target_hash:
                    return {'found': True, 'password': candidate_str, 'attempts': attempts, 'method': 'Smart Brute Force'}
                
                if attempts >= max_attempts:
                    break
        
        elif password_length == 4:
            # For 4-char passwords, use incremental approach
            char_priority = '0123456789abcdefghijklmnopqrstuvwxyz'
            
            # Try patterns: digits first, then lowercase
            for first in char_priority:
                for second in char_priority:
                    for third in char_priority:
                        for fourth in char_priority:
                            attempts += 1
                            candidate_str = first + second + third + fourth
                            if hash_type == 'md5':
                                candidate_hash = hashlib.md5(candidate_str.encode()).hexdigest()
                            else:
                                candidate_hash = hashlib.sha256(candidate_str.encode()).hexdigest()
                            
                            if candidate_hash == target_hash:
                                return {'found': True, 'password': candidate_str, 'attempts': attempts, 'method': 'Incremental Brute Force'}
                            
                            
        return {'found': False, 'attempts': attempts, 'method': 'Brute Force', 'reason': 'Password too complex or long'}

    def simulate_comprehensive_attack(self, password, max_length=4):
        """Perform comprehensive attack simulation"""
        if not password:
            return {'error': 'No password provided'}
        
        if len(password) > max_length:
            theoretical_time = self.calculate_theoretical_crack_time(password)
            return {
                'error': f'Password too long for simulation (max {max_length} chars)',
                'length': len(password),
                'theoretical_time': theoretical_time,
                'charset_size': len(self.get_charset(password)),
                'total_combinations': len(self.get_charset(password)) ** len(password)
            }
        
        target_hash_md5 = hashlib.md5(password.encode()).hexdigest()
        target_hash_sha256 = hashlib.sha256(password.encode()).hexdigest()
        charset = self.get_charset(password)
        
        start_time = time.time()
        total_attempts = 0
        
        # Attack sequence
        attacks = []
        
        # 1. Dictionary Attack
        dict_result = self.dictionary_attack(target_hash_md5)
        attacks.append(dict_result)
        total_attempts += dict_result['attempts']
        
        if dict_result['found']:
            elapsed_time = time.time() - start_time
            return self._format_success_result(dict_result, total_attempts, elapsed_time, attacks)
        
        # 2. Hybrid Attack
        hybrid_result = self.hybrid_attack(target_hash_md5, len(password))
        attacks.append(hybrid_result)
        total_attempts += hybrid_result['attempts']
        
        if hybrid_result['found']:
            elapsed_time = time.time() - start_time
            return self._format_success_result(hybrid_result, total_attempts, elapsed_time, attacks)
        
        # 3. Mask/Brute Force Attack
        mask_result = self.mask_attack(target_hash_md5, len(password), charset)
        attacks.append(mask_result)
        total_attempts += mask_result['attempts']
        
        elapsed_time = time.time() - start_time
        
        if mask_result['found']:
            return self._format_success_result(mask_result, total_attempts, elapsed_time, attacks)
        else:
            return self._format_failure_result(total_attempts, elapsed_time, attacks, password, charset)

    def _format_success_result(self, winning_attack, total_attempts, elapsed_time, all_attacks):
        """Format successful crack result"""
        return {
            'found': True,
            'password': winning_attack['password'],
            'total_attempts': total_attempts,
            'time': elapsed_time,
            'rate': round(total_attempts / elapsed_time) if elapsed_time > 0 else 0,
            'winning_method': winning_attack['method'],
            'attack_sequence': [
                {
                    'method': attack['method'],
                    'attempts': attack['attempts'],
                    'found': attack['found']
                } for attack in all_attacks
            ]
        }

    def _format_failure_result(self, total_attempts, elapsed_time, all_attacks, password, charset):
        """Format failed crack result"""
        theoretical_time = self.calculate_theoretical_crack_time(password)
        
        return {
            'found': False,
            'total_attempts': total_attempts,
            'time': elapsed_time,
            'rate': round(total_attempts / elapsed_time) if elapsed_time > 0 else 0,
            'reason': 'Password not found in attempted methods',
            'theoretical_time': theoretical_time,
            'charset_size': len(charset),
            'total_combinations': len(charset) ** len(password),
            'attack_sequence': [
                {
                    'method': attack['method'],
                    'attempts': attack['attempts'],
                    'found': attack['found']
                } for attack in all_attacks
            ]
        }

    def calculate_theoretical_crack_time(self, password):
        """Calculate theoretical time to crack password"""
        charset = self.get_charset(password)
        combinations = len(charset) ** len(password)
        
        # Assume 1 billion attempts per second (modern GPU)
        attempts_per_second = 1_000_000_000
        
        # Average case: half the search space
        avg_combinations = combinations / 2
        
        seconds = avg_combinations / attempts_per_second
        
        if seconds < 60:
            return f"{seconds:.2f} seconds"
        elif seconds < 3600:
            return f"{seconds/60:.2f} minutes"
        elif seconds < 86400:
            return f"{seconds/3600:.2f} hours"
        elif seconds < 31536000:
            return f"{seconds/86400:.2f} days"
        else:
            years = seconds / 31536000
            if years > 1_000_000:
                return f"{years:.2e} years (practically impossible)"
            else:
                return f"{years:.2f} years"

# Initialize analyzers
password_analyzer = PasswordAnalyzer()
hash_generator = HashGenerator()
brute_force_simulator = EnhancedBruteForceSimulator()

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_password():
    """API endpoint for password analysis"""
    data = request.get_json()
    password = data.get('password', '')
    
    analysis = password_analyzer.analyze_password(password)
    return jsonify(analysis)

@app.route('/api/hash', methods=['POST'])
def generate_hashes():
    """API endpoint for hash generation"""
    data = request.get_json()
    password = data.get('password', '')
    
    hashes = hash_generator.generate_hashes(password)
    return jsonify(hashes)

@app.route('/api/crack', methods=['POST'])
def simulate_brute_force():
    """API endpoint for comprehensive crack simulation"""
    data = request.get_json()
    password = data.get('password', '')
    
    result = brute_force_simulator.simulate_comprehensive_attack(password)
    return jsonify(result)

@app.route('/api/theoretical-time', methods=['POST'])
def get_theoretical_time():
    """API endpoint for theoretical crack time calculation"""
    data = request.get_json()
    password = data.get('password', '')
    
    if not password:
        return jsonify({'error': 'No password provided'})
    
    theoretical_time = brute_force_simulator.calculate_theoretical_crack_time(password)
    charset = brute_force_simulator.get_charset(password)
    
    return jsonify({
        'theoretical_time': theoretical_time,
        'charset_size': len(charset),
        'total_combinations': len(charset) ** len(password),
        'password_length': len(password)
    })

if __name__ == '__main__':
    app.run(debug=True)