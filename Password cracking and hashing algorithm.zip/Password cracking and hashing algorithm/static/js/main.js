// Enhanced main.js with improved security and expanded cracking capabilities

class SecurePasswordApp {
    constructor() {
        this.currentPassword = '';
        this.activeTab = 'analyzer';
        this.showPassword = false;
        this.debounceTimer = null;
        this.csrfToken = this.generateCSRFToken();
        this.rateLimiter = new RateLimiter(100, 60000); // 100 requests per minute
        this.requestQueue = new RequestQueue();
        
        this.init();
    }

    init() {
        this.setupSecurityHeaders();
        this.bindEvents();
        this.switchTab('analyzer');
        this.initializeSecurityFeatures();
    }

    generateCSRFToken() {
        return Array.from(crypto.getRandomValues(new Uint8Array(32)))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
    }

    setupSecurityHeaders() {
        // Add security headers to all requests
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': this.csrfToken
        };
    }

    initializeSecurityFeatures() {
        // Prevent context menu on sensitive elements
        document.querySelectorAll('input[type="password"], .hash-display').forEach(element => {
            element.addEventListener('contextmenu', e => e.preventDefault());
        });

        // Clear clipboard after copy
        this.setupSecureClipboard();
        
        // Monitor for DevTools
        this.setupDevToolsDetection();
    }

    setupSecureClipboard() {
        let clipboardTimeout;
        const originalWriteText = navigator.clipboard.writeText;
        navigator.clipboard.writeText = function(text) {
            clearTimeout(clipboardTimeout);
            clipboardTimeout = setTimeout(() => {
                // Clear clipboard after 30 seconds
                navigator.clipboard.writeText('').catch(() => {});
            }, 30000);
            return originalWriteText.call(this, text);
        };
    }

    setupDevToolsDetection() {
        // Basic devtools detection (for educational awareness)
        let devtools = { open: false };
        setInterval(() => {
            if (window.outerHeight - window.innerHeight > 160 || window.outerWidth - window.innerWidth > 160) {
                if (!devtools.open) {
                    devtools.open = true;
                    console.clear();
                    console.warn('🔒 Security Notice: Developer tools detected. This is an educational security toolkit.');
                }
            } else {
                devtools.open = false;
            }
        }, 1000);
    }

    bindEvents() {
        // Password input with enhanced security
        const passwordInput = document.getElementById('passwordInput');
        passwordInput.addEventListener('input', (e) => {
            this.handlePasswordChange(e.target.value);
        });

        // Prevent password field from being autocompleted
        passwordInput.setAttribute('autocomplete', 'new-password');
        passwordInput.setAttribute('data-lpignore', 'true');

        // Clear password on page unload
        window.addEventListener('beforeunload', () => {
            passwordInput.value = '';
            this.currentPassword = '';
        });

        // Toggle password visibility
        const togglePassword = document.getElementById('togglePassword');
        togglePassword.addEventListener('click', () => {
            this.togglePasswordVisibility();
        });

        // Tab buttons
        document.getElementById('analyzerTab').addEventListener('click', () => {
            this.switchTab('analyzer');
        });
        document.getElementById('hasherTab').addEventListener('click', () => {
            this.switchTab('hasher');
        });
        document.getElementById('crackerTab').addEventListener('click', () => {
            this.switchTab('cracker');
        });

        // Enhanced brute force button
        document.getElementById('startCracking').addEventListener('click', () => {
            this.startEnhancedCracking();
        });
    }

    async makeSecureRequest(url, data) {
        if (!this.rateLimiter.canMakeRequest()) {
            throw new Error('Rate limit exceeded. Please wait before making another request.');
        }

        const requestData = {
            ...data,
            timestamp: Date.now(),
            nonce: crypto.getRandomValues(new Uint32Array(1))[0]
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: this.defaultHeaders,
                body: JSON.stringify(requestData),
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Secure request failed:', error);
            throw error;
        }
    }

    handlePasswordChange(password) {
        // Sanitize input
        const sanitized = this.sanitizeInput(password);
        this.currentPassword = sanitized;
        
        // Debounce API calls
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => {
            this.updateContent();
        }, 300);
    }

    sanitizeInput(input) {
        // Basic input sanitization while preserving password characters
        return input.substring(0, 128); // Limit length
    }

    togglePasswordVisibility() {
        this.showPassword = !this.showPassword;
        const passwordInput = document.getElementById('passwordInput');
        const eyeIcon = document.getElementById('eyeIcon');
        
        passwordInput.type = this.showPassword ? 'text' : 'password';
        
        // Update icon with security consideration
        if (this.showPassword) {
            eyeIcon.innerHTML = `
                <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/>
                <path d="m10.73 5.08 4.18 4.18"/>
                <path d="m15.02 15.02 4.18 4.18"/>
                <path d="M2 2l20 20"/>
            `;
            // Auto-hide password after 10 seconds
            setTimeout(() => {
                if (this.showPassword) {
                    this.togglePasswordVisibility();
                }
            }, 10000);
        } else {
            eyeIcon.innerHTML = `
                <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
                <circle cx="12" cy="12" r="3"/>
            `;
        }
    }

    switchTab(tabName) {
        this.activeTab = tabName;
        
        // Update tab buttons with enhanced styling
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.className = 'tab-button flex items-center px-6 py-3 rounded-xl font-medium transition-all duration-300 glass-card text-slate-300 hover:glass-card-hover border border-white/10';
        });
        
        const activeTabButton = document.getElementById(tabName + 'Tab');
        activeTabButton.className = 'tab-button flex items-center px-6 py-3 rounded-xl font-medium transition-all duration-300 glass-card-active text-white shadow-2xl border border-purple-400/30';
        activeTabButton.classList.add('active');
        
        // Update content visibility with animation
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        
        const activeContent = document.getElementById(tabName + 'Content');
        activeContent.classList.remove('hidden');
        activeContent.style.animation = 'fadeInScale 0.4s ease-out';
        
        this.updateContent();
    }

    async updateContent() {
        try {
            switch (this.activeTab) {
                case 'analyzer':
                    await this.updatePasswordAnalysis();
                    break;
                case 'hasher':
                    await this.updateHashResults();
                    break;
                case 'cracker':
                    this.updateBruteForceUI();
                    break;
            }
        } catch (error) {
            this.handleError(error);
        }
    }

    async updatePasswordAnalysis() {
        const resultsContainer = document.getElementById('strengthResults');
        
        if (!this.currentPassword) {
            resultsContainer.innerHTML = this.getEmptyAnalysisHTML();
            return;
        }

        this.showLoading();
        
        try {
            const analysis = await this.makeSecureRequest('/api/analyze', { 
                password: this.currentPassword 
            });
            
            if (analysis) {
                resultsContainer.innerHTML = this.generateEnhancedAnalysisHTML(analysis);
                this.animateResults();
            }
        } catch (error) {
            console.error('Error analyzing password:', error);
            resultsContainer.innerHTML = this.getErrorHTML('Failed to analyze password: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }

    async updateHashResults() {
        const resultsContainer = document.getElementById('hashResults');
        
        if (!this.currentPassword) {
            resultsContainer.innerHTML = this.getEmptyHashHTML();
            return;
        }

        this.showLoading();
        
        try {
            const hashes = await this.makeSecureRequest('/api/hash', { 
                password: this.currentPassword 
            });
            
            if (hashes) {
                resultsContainer.innerHTML = this.generateEnhancedHashHTML(hashes);
                this.setupHashCopyHandlers();
            }
        } catch (error) {
            console.error('Error generating hashes:', error);
            resultsContainer.innerHTML = this.getErrorHTML('Failed to generate hashes: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }

    updateBruteForceUI() {
        const startButton = document.getElementById('startCracking');
        const warningDiv = document.getElementById('tooLongWarning');
        
        // Enhanced length checking with better limits
        if (this.currentPassword && this.currentPassword.length > 6) {
            startButton.disabled = true;
            warningDiv.classList.remove('hidden');
            warningDiv.innerHTML = `
                <div class="glass-card border-orange-400/30 p-4 rounded-xl">
                    <div class="flex items-center text-orange-300">
                        <svg class="lucide-icon w-5 h-5 mr-2" viewBox="0 0 24 24">
                            <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>
                            <path d="M12 9v4"/>
                            <path d="M12 17h.01"/>
                        </svg>
                        Password too complex for simulation (max 6 characters for demo)
                    </div>
                    <div class="text-orange-200 text-sm mt-2">
                        ${this.calculateTheoreticalTime(this.currentPassword)}
                    </div>
                </div>
            `;
        } else {
            startButton.disabled = false;
            warningDiv.classList.add('hidden');
        }
    }

    calculateTheoreticalTime(password) {
        if (!password) return '';
        
        let charsetSize = 0;
        if (/[a-z]/.test(password)) charsetSize += 26;
        if (/[A-Z]/.test(password)) charsetSize += 26;
        if (/[0-9]/.test(password)) charsetSize += 10;
        if (/[^a-zA-Z0-9]/.test(password)) charsetSize += 32;
        
        const combinations = Math.pow(charsetSize, password.length);
        const attemptsPerSecond = 1000000000; // 1 billion per second
        const seconds = combinations / (2 * attemptsPerSecond); // Average case
        
        if (seconds < 1) return 'Estimated crack time: < 1 second';
        if (seconds < 60) return `Estimated crack time: ${seconds.toFixed(1)} seconds`;
        if (seconds < 3600) return `Estimated crack time: ${(seconds/60).toFixed(1)} minutes`;
        if (seconds < 86400) return `Estimated crack time: ${(seconds/3600).toFixed(1)} hours`;
        if (seconds < 31536000) return `Estimated crack time: ${(seconds/86400).toFixed(1)} days`;
        return `Estimated crack time: ${(seconds/31536000).toFixed(1)} years`;
    }

    async startEnhancedCracking() {
        if (!this.currentPassword || this.currentPassword.length > 6) {
            this.showNotification('For demonstration, please use passwords up to 6 characters', 'warning');
            return;
        }

        const startButton = document.getElementById('startCracking');
        const resultsDiv = document.getElementById('bruteForceResults');
        
        startButton.disabled = true;
        startButton.innerHTML = `
            <div class="flex items-center">
                <div class="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                <span>Analyzing...</span>
            </div>
        `;
        
        this.showLoading();
        
        try {
            const result = await this.makeSecureRequest('/api/crack', { 
                password: this.currentPassword 
            });
            
            if (result.error) {
                this.showNotification(result.error, 'error');
                if (result.theoretical_time) {
                    resultsDiv.innerHTML = this.generateTheoreticalTimeHTML(result);
                    resultsDiv.classList.remove('hidden');
                }
            } else {
                resultsDiv.innerHTML = this.generateEnhancedBruteForceHTML(result);
                resultsDiv.classList.remove('hidden');
                this.animateResults();
            }
        } catch (error) {
            console.error('Error in brute force simulation:', error);
            this.showNotification('Error running simulation: ' + error.message, 'error');
        } finally {
            startButton.disabled = false;
            startButton.innerHTML = `
                <svg class="lucide-icon w-5 h-5 mr-2" viewBox="0 0 24 24">
                    <polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/>
                </svg>
                Start Enhanced Simulation
            `;
            this.hideLoading();
        }
    }

    setupHashCopyHandlers() {
        document.querySelectorAll('.hash-display').forEach(element => {
            element.addEventListener('click', async () => {
                const text = element.textContent.trim();
                try {
                    await navigator.clipboard.writeText(text);
                    this.showCopyFeedback(element);
                    
                    // Security log
                    console.log('Hash copied to clipboard - will auto-clear in 30 seconds');
                } catch (error) {
                    console.error('Failed to copy to clipboard:', error);
                    this.showNotification('Failed to copy to clipboard', 'error');
                }
            });
        });
    }

    showCopyFeedback(element) {
        const original = element.style.background;
        element.style.background = 'linear-gradient(135deg, rgba(34, 197, 94, 0.3), rgba(34, 197, 94, 0.1))';
        element.style.transform = 'scale(1.02)';
        
        setTimeout(() => {
            element.style.background = original;
            element.style.transform = 'scale(1)';
        }, 300);
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 glass-card-active border-l-4 p-4 rounded-xl shadow-2xl z-50 transform translate-x-full transition-transform duration-300 ${
            type === 'error' ? 'border-red-400' : 
            type === 'warning' ? 'border-orange-400' : 
            'border-blue-400'
        }`;
        
        notification.innerHTML = `
            <div class="flex items-center">
                <svg class="lucide-icon w-5 h-5 mr-2 ${
                    type === 'error' ? 'text-red-400' : 
                    type === 'warning' ? 'text-orange-400' : 
                    'text-blue-400'
                }" viewBox="0 0 24 24">
                    ${type === 'error' ? 
                        '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>' :
                        '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>'
                    }
                </svg>
                <span class="text-white">${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        setTimeout(() => {
            notification.style.transform = 'translateX(full)';
            setTimeout(() => document.body.removeChild(notification), 300);
        }, 4000);
    }

    animateResults() {
        const elements = document.querySelectorAll('.result-card, .recommendation-item, .status-indicator');
        elements.forEach((el, index) => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            setTimeout(() => {
                el.style.transition = 'all 0.4s ease-out';
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }

    handleError(error) {
        console.error('Application error:', error);
        this.showNotification('An unexpected error occurred. Please try again.', 'error');
    }

    showLoading() {
        document.getElementById('loadingIndicator').classList.remove('hidden');
    }

    hideLoading() {
        document.getElementById('loadingIndicator').classList.add('hidden');
    }

    // Enhanced HTML generators with glassmorphism styling
    generateEnhancedAnalysisHTML(analysis) {
        const barColor = analysis.score >= 80 ? 'from-green-500 to-green-400' :
                        analysis.score >= 60 ? 'from-blue-500 to-blue-400' :
                        analysis.score >= 40 ? 'from-yellow-500 to-yellow-400' :
                        analysis.score >= 20 ? 'from-orange-500 to-orange-400' : 
                        'from-red-500 to-red-400';

        return `
            <div class="space-y-6">
                <!-- Enhanced Strength Score -->
                <div class="glass-card glass-glow border border-white/20 p-6 rounded-2xl">
                    <div class="flex items-center justify-between mb-4">
                        <span class="text-white font-semibold text-lg">Overall Strength</span>
                        <span class="font-bold text-2xl bg-gradient-to-r ${analysis.strength.color.replace('text-', 'from-').replace('-600', '-400')} to-white bg-clip-text text-transparent">
                            ${analysis.strength.rating}
                        </span>
                    </div>
                    <div class="relative w-full bg-black/30 rounded-full h-4 overflow-hidden backdrop-blur-sm">
                        <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-pulse"></div>
                        <div class="strength-bar h-4 rounded-full bg-gradient-to-r ${barColor} transition-all duration-1000 relative overflow-hidden" style="width: ${analysis.score}%">
                            <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
                        </div>
                    </div>
                    <div class="text-slate-300 text-sm mt-2 flex justify-between">
                        <span>Security Score</span>
                        <span class="font-mono">${analysis.score}/100</span>
                    </div>
                </div>

                <!-- Enhanced Metrics Grid -->
                <div class="grid md:grid-cols-2 gap-6">
                    ${this.generateMetricsSection(analysis)}
                    ${this.generateIssuesSection(analysis)}
                </div>

                ${analysis.recommendations && analysis.recommendations.length > 0 ? this.generateRecommendationsSection(analysis.recommendations) : ''}
            </div>
        `;
    }

    generateMetricsSection(analysis) {
        const metrics = [
            { label: 'Length', value: `${analysis.length} characters`, good: analysis.length >= 8, icon: 'ruler' },
            { label: 'Lowercase', value: analysis.has_lowercase ? 'Present' : 'Missing', good: analysis.has_lowercase, icon: 'type' },
            { label: 'Uppercase', value: analysis.has_uppercase ? 'Present' : 'Missing', good: analysis.has_uppercase, icon: 'type' },
            { label: 'Digits', value: analysis.has_digits ? 'Present' : 'Missing', good: analysis.has_digits, icon: 'hash' },
            { label: 'Special Chars', value: analysis.has_special ? 'Present' : 'Missing', good: analysis.has_special, icon: 'at-sign' }
        ];

        return `
            <div class="glass-card border border-white/10 p-6 rounded-2xl">
                <h3 class="text-lg font-semibold text-white mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                    Password Composition
                </h3>
                <div class="space-y-3">
                    ${metrics.map((item, index) => `
                        <div class="flex items-center justify-between p-3 rounded-xl bg-black/20 backdrop-blur-sm border border-white/5 hover:border-white/10 transition-all duration-300" style="animation-delay: ${index * 0.1}s">
                            <span class="text-slate-300 flex items-center">
                                <span class="w-2 h-2 rounded-full ${item.good ? 'bg-green-400' : 'bg-red-400'} mr-3"></span>
                                ${item.label}
                            </span>
                            <span class="${item.good ? 'text-green-300' : 'text-red-300'} font-medium">
                                ${item.value}
                            </span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    generateIssuesSection(analysis) {
        const issues = [
            { label: 'Common Password', bad: analysis.is_common, icon: 'users' },
            { label: 'Repeated Characters', bad: analysis.has_repeated, icon: 'repeat' },
            { label: 'Sequential Pattern', bad: analysis.has_sequential, icon: 'trending-up' }
        ];

        return `
            <div class="glass-card border border-white/10 p-6 rounded-2xl">
                <h3 class="text-lg font-semibold text-white mb-4 bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">
                    Security Analysis
                </h3>
                <div class="space-y-3">
                    ${issues.map((item, index) => `
                        <div class="flex items-center justify-between p-3 rounded-xl bg-black/20 backdrop-blur-sm border border-white/5 hover:border-white/10 transition-all duration-300" style="animation-delay: ${index * 0.1}s">
                            <span class="text-slate-300 flex items-center">
                                <span class="w-2 h-2 rounded-full ${item.bad ? 'bg-red-400' : 'bg-green-400'} mr-3"></span>
                                ${item.label}
                            </span>
                            <span class="${item.bad ? 'text-red-300' : 'text-green-300'} font-medium">
                                ${item.bad ? 'Detected' : 'Secure'}
                            </span>
                        </div>
                    `).join('')}
                    <div class="pt-3 border-t border-white/10">
                        <div class="flex justify-between items-center">
                            <span class="text-slate-300">Entropy</span>
                            <span class="text-blue-300 font-mono">${analysis.entropy.toFixed(1)} bits</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    generateRecommendationsSection(recommendations) {
        return `
            <div class="glass-card glass-glow-orange border border-orange-400/20 rounded-2xl p-6">
                <h3 class="text-lg font-semibold mb-4 flex items-center bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent">
                    <svg class="lucide-icon w-5 h-5 mr-2 text-orange-400" viewBox="0 0 24 24">
                        <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>
                        <path d="M12 9v4"/>
                        <path d="M12 17h.01"/>
                    </svg>
                    Security Recommendations
                </h3>
                <div class="space-y-2">
                    ${recommendations.map((rec, index) => `
                        <div class="recommendation-item flex items-start p-3 rounded-xl bg-black/20 backdrop-blur-sm border border-orange-400/10" style="animation-delay: ${index * 0.1}s">
                            <span class="text-orange-400 mr-3 mt-0.5">•</span>
                            <span class="text-orange-200">${rec}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    generateEnhancedHashHTML(hashes) {
        return `
            <div class="space-y-6">
                <div class="glass-card border border-red-400/20 rounded-2xl p-6">
                    <h3 class="text-lg font-semibold text-white mb-4 flex items-center">
                        <span class="w-3 h-3 bg-red-400 rounded-full mr-3"></span>
                        Unsalted Hashes (Vulnerable)
                    </h3>
                    <div class="space-y-4">
                        ${this.generateHashItem('MD5', hashes.md5, 'red', 'Cryptographically broken - avoid')}
                        ${this.generateHashItem('SHA-256', hashes.sha256, 'yellow', 'Better but still vulnerable without salt')}
                    </div>
                </div>

                <div class="glass-card border border-green-400/20 rounded-2xl p-6">
                    <h3 class="text-lg font-semibold text-white mb-4 flex items-center">
                        <span class="w-3 h-3 bg-green-400 rounded-full mr-3"></span>
                        Salted Hashes (More Secure)
                    </h3>
                    <div class="space-y-4">
                        ${this.generateHashItem('Salt', hashes.salt, 'blue', 'Random salt for this password')}
                        ${this.generateHashItem('MD5 + Salt', hashes.md5_salted, 'green', 'Salted but still use stronger algorithm')}
                        ${this.generateHashItem('SHA-256 + Salt', hashes.sha256_salted, 'green', 'Much more secure with salt')}
                    </div>
                </div>

                <div class="glass-card glass-glow-blue border border-blue-400/20 rounded-2xl p-6">
                    <h3 class="text-lg font-semibold mb-4 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                        🔐 Security Best Practices
                    </h3>
                    <div class="grid md:grid-cols-2 gap-4 text-sm">
                        <div class="space-y-2">
                            <div class="text-blue-200">✓ Always use salts</div>
                            <div class="text-blue-200">✓ Use bcrypt, Argon2, or PBKDF2</div>
                            <div class="text-blue-200">✓ Proper iteration counts</div>
                        </div>
                        <div class="space-y-2">
                            <div class="text-red-200">✗ Never use MD5 or SHA-1</div>
                            <div class="text-red-200">✗ Avoid unsalted hashes</div>
                            <div class="text-red-200">✗ Don't roll your own crypto</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    generateHashItem(label, hash, color, description) {
        return `
            <div class="group">
                <div class="flex justify-between items-center mb-2">
                    <label class="text-slate-300 font-medium">${label}:</label>
                    <span class="text-xs text-${color}-400">${description}</span>
                </div>
                <div class="hash-display glass-card border border-white/10 p-4 rounded-xl text-${color}-300 break-all font-mono text-sm cursor-pointer hover:glass-card-hover transition-all duration-300 group-hover:scale-[1.02]" data-tooltip="Click to copy">
                    ${hash}
                </div>
            </div>
        `;
    }

    generateEnhancedBruteForceHTML(result) {
        const bgClass = result.found ? 
            'glass-card glass-glow-red border-red-400/30' : 
            'glass-card border-green-400/30';
        
        return `
            <div class="${bgClass} rounded-2xl p-6">
                <h3 class="text-xl font-semibold text-white mb-6 flex items-center">
                    <svg class="lucide-icon w-6 h-6 mr-3" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12,6 12,12 16,14"/>
                    </svg>
                    ${result.found ? 'Password Compromised!' : 'Password Secure'}
                </h3>
                
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                    <div class="glass-card border border-white/10 p-4 rounded-xl">
                        <div class="text-slate-300 text-sm mb-1">Status</div>
                        <div class="flex items-center">
                            ${result.found ? 
                                '<span class="w-3 h-3 bg-red-400 rounded-full mr-2 animate-pulse"></span><span class="text-red-300 font-semibold">Cracked</span>' :
                                '<span class="w-3 h-3 bg-green-400 rounded-full mr-2"></span><span class="text-green-300 font-semibold">Secure</span>'
                            }
                        </div>
                    </div>

                    ${result.found && result.password ? `
                        <div class="glass-card border border-red-400/30 p-4 rounded-xl">
                            <div class="text-slate-300 text-sm mb-1">Found Password</div>
                            <div class="text-red-300 font-mono font-bold">${result.password}</div>
                        </div>
                    ` : ''}

                    <div class="glass-card border border-white/10 p-4 rounded-xl">
                        <div class="text-slate-300 text-sm mb-1">Total Attempts</div>
                        <div class="text-white font-bold">${result.total_attempts?.toLocaleString() || result.attempts?.toLocaleString()}</div>
                    </div>

                    <div class="glass-card border border-white/10 p-4 rounded-xl">
                        <div class="text-slate-300 text-sm mb-1">Time Elapsed</div>
                        <div class="text-white font-bold">${result.time?.toFixed(3)}s</div>
                    </div>

                    ${result.rate ? `
                        <div class="glass-card border border-white/10 p-4 rounded-xl">
                            <div class="text-slate-300 text-sm mb-1">Attack Rate</div>
                            <div class="text-white font-bold">${result.rate.toLocaleString()}/sec</div>
                        </div>
                    ` : ''}

                    ${result.winning_method ? `
                        <div class="glass-card border border-purple-400/30 p-4 rounded-xl">
                            <div class="text-slate-300 text-sm mb-1">Success Method</div>
                            <div class="text-purple-300 font-bold">${result.winning_method}</div>
                        </div>
                    ` : ''}
                </div>

                ${result.attack_sequence ? this.generateAttackSequenceHTML(result.attack_sequence) : ''}
                
                ${result.theoretical_time ? `
                    <div class="glass-card glass-glow-blue border border-blue-400/20 rounded-xl p-4 mt-4">
                        <div class="text-blue-300 font-medium mb-2">Theoretical Analysis</div>
                        <div class="text-blue-200 text-sm">${result.theoretical_time}</div>
                        <div class="text-slate-400 text-xs mt-1">
                            Charset: ${result.charset_size} chars, Combinations: ${result.total_combinations?.toLocaleString()}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    generateAttackSequenceHTML(sequence) {
        return `
            <div class="glass-card border border-white/10 rounded-xl p-4 mb-4">
                <h4 class="text-white font-medium mb-3">Attack Sequence</h4>
                <div class="space-y-2">
                    ${sequence.map((attack, index) => `
                        <div class="flex items-center justify-between p-2 rounded-lg ${attack.found ? 'bg-red-900/30' : 'bg-slate-800/30'}">
                            <div class="flex items-center">
                                <span class="text-xs font-mono w-4">${index + 1}.</span>
                                <span class="text-slate-300 ml-2">${attack.method}</span>
                            </div>
                            <div class="flex items-center text-sm">
                                <span class="text-slate-400 mr-2">${attack.attempts.toLocaleString()}</span>
                                ${attack.found ? 
                                    '<span class="w-2 h-2 bg-red-400 rounded-full"></span>' : 
                                    '<span class="w-2 h-2 bg-slate-600 rounded-full"></span>'
                                }
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    generateTheoreticalTimeHTML(result) {
        return `
            <div class="glass-card glass-glow-orange border border-orange-400/30 rounded-2xl p-6">
                <h3 class="text-xl font-semibold text-white mb-4 flex items-center">
                    <svg class="lucide-icon w-6 h-6 mr-3 text-orange-400" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12,6 12,12 16,14"/>
                    </svg>
                    Theoretical Analysis
                </h3>
                <div class="space-y-4">
                    <div class="text-orange-200">
                        <strong>Password Length:</strong> ${result.length} characters
                    </div>
                    <div class="text-orange-200">
                        <strong>Character Set Size:</strong> ${result.charset_size} unique characters
                    </div>
                    <div class="text-orange-200">
                        <strong>Total Combinations:</strong> ${result.total_combinations?.toLocaleString()}
                    </div>
                    <div class="text-orange-200">
                        <strong>Estimated Crack Time:</strong> ${result.theoretical_time}
                    </div>
                    <div class="glass-card border border-orange-400/20 rounded-xl p-4 mt-4">
                        <div class="text-orange-300 font-medium mb-2">Security Note</div>
                        <div class="text-orange-200 text-sm">
                            This password is too complex for our simulation but could potentially be cracked 
                            with sufficient computational resources and time.
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    getEmptyAnalysisHTML() {
        return `
            <div class="text-center py-16">
                <div class="glass-card border border-white/10 rounded-2xl p-8 max-w-md mx-auto">
                    <svg class="lucide-icon w-20 h-20 mx-auto mb-6 text-slate-500" viewBox="0 0 24 24">
                        <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>
                        <path d="m7 11V7a5 5 0 0 1 10 0v4"/>
                    </svg>
                    <p class="text-slate-400 text-lg">Enter a password above to begin security analysis</p>
                    <p class="text-slate-500 text-sm mt-2">Get real-time strength assessment and recommendations</p>
                </div>
            </div>
        `;
    }

    getEmptyHashHTML() {
        return `
            <div class="text-center py-16">
                <div class="glass-card border border-white/10 rounded-2xl p-8 max-w-md mx-auto">
                    <svg class="lucide-icon w-20 h-20 mx-auto mb-6 text-slate-500" viewBox="0 0 24 24">
                        <line x1="4" x2="20" y1="9" y2="9"/>
                        <line x1="4" x2="20" y1="15" y2="15"/>
                        <line x1="10" x2="14" y1="3" y2="21"/>
                    </svg>
                    <p class="text-slate-400 text-lg">Enter a password to generate cryptographic hashes</p>
                    <p class="text-slate-500 text-sm mt-2">Compare secure vs insecure hashing methods</p>
                </div>
            </div>
        `;
    }

    getErrorHTML(message) {
        return `
            <div class="text-center py-16">
                <div class="glass-card glass-glow-red border border-red-400/30 rounded-2xl p-8 max-w-md mx-auto">
                    <svg class="lucide-icon w-20 h-20 mx-auto mb-6 text-red-400" viewBox="0 0 24 24">
                        <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>
                        <path d="M12 9v4"/>
                        <path d="M12 17h.01"/>
                    </svg>
                    <p class="text-red-300 text-lg font-medium">Error</p>
                    <p class="text-red-200 text-sm mt-2">${message}</p>
                </div>
            </div>
        `;
    }
}

// Enhanced utility classes
class RateLimiter {
    constructor(maxRequests, timeWindow) {
        this.maxRequests = maxRequests;
        this.timeWindow = timeWindow;
        this.requests = [];
    }

    canMakeRequest() {
        const now = Date.now();
        this.requests = this.requests.filter(time => now - time < this.timeWindow);
        
        if (this.requests.length >= this.maxRequests) {
            return false;
        }
        
        this.requests.push(now);
        return true;
    }
}

class RequestQueue {
    constructor() {
        this.queue = [];
        this.processing = false;
    }

    async add(request) {
        return new Promise((resolve, reject) => {
            this.queue.push({ request, resolve, reject });
            this.process();
        });
    }

    async process() {
        if (this.processing || this.queue.length === 0) return;
        
        this.processing = true;
        
        while (this.queue.length > 0) {
            const { request, resolve, reject } = this.queue.shift();
            try {
                const result = await request();
                resolve(result);
            } catch (error) {
                reject(error);
            }
            
            // Small delay between requests
            await new Promise(resolve => setTimeout(resolve, 50));
        }
        
        this.processing = false;
    }
}

// Initialize the enhanced application
document.addEventListener('DOMContentLoaded', function() {
    // Security check
    if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
        console.warn('⚠️ This security toolkit should only be used over HTTPS in production.');
    }
    
    new SecurePasswordApp();
});

// Enhanced click-to-copy functionality with security features
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('hash-display')) {
        e.preventDefault();
        const text = e.target.textContent.trim();
        
        navigator.clipboard.writeText(text).then(() => {
            // Visual feedback
            const original = e.target.style.transform;
            e.target.style.transform = 'scale(1.02)';
            e.target.style.background = 'linear-gradient(135deg, rgba(34, 197, 94, 0.3), rgba(34, 197, 94, 0.1))';
            
            setTimeout(() => {
                e.target.style.transform = original;
                e.target.style.background = '';
            }, 300);
            
            // Security logging
            console.log(`Hash copied - Type: ${e.target.previousElementSibling?.textContent || 'Unknown'}`);
        }).catch(err => {
            console.error('Copy failed:', err);
        });
    }
});

// Security event listeners
window.addEventListener('beforeunload', () => {
    // Clear sensitive data
    document.querySelectorAll('input[type="password"]').forEach(input => {
        input.value = '';
    });
});

// Prevent drag and drop of sensitive elements
document.addEventListener('dragstart', (e) => {
    if (e.target.classList.contains('hash-display') || e.target.type === 'password') {
        e.preventDefault();
    }
});